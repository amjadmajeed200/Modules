<?php
namespace Cooperative\Customwork\Block;

class Wholesale extends  \Magento\Framework\View\Element\Template
{

    public function getPro()
    {
        echo 'a';
    }
    /**
     * Returns action url for Wholesale form
     *
     * @return string
     */
    public function getFormAction(){

        return $this->getUrl('customwork/index/post', ['_secure' => true]);


    }
}
